// 1. Header Scrolled Shadow & Active Nav Link Highlighting on Scroll
const mainHeader = document.getElementById('main-header');
const allSections = document.querySelectorAll('section');
const navAnchors = document.querySelectorAll('#nav-links a');

window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
        mainHeader.classList.add('scrolled');
    } else {
        mainHeader.classList.remove('scrolled');
    }

    let currentId = 'command';
    allSections.forEach(sec => {
        const top = sec.offsetTop - 140;
        if (window.scrollY >= top) {
            currentId = sec.getAttribute('id');
        }
    });

    navAnchors.forEach(a => {
        a.classList.remove('active');
        if (a.getAttribute('href') === `#${currentId}`) {
            a.classList.add('active');
        }
    });
});

// 2. Mobile Menu with Animated Icon Toggle
const menuBtn = document.getElementById('menu-toggle');
const navLinks = document.getElementById('nav-links');
menuBtn.onclick = () => {
    navLinks.classList.toggle('open');
    const icon = menuBtn.querySelector('i');
    if (navLinks.classList.contains('open')) {
        icon.className = 'fa-solid fa-xmark';
    } else {
        icon.className = 'fa-solid fa-bars';
    }
};
navLinks.querySelectorAll('a').forEach(a => a.onclick = () => {
    navLinks.classList.remove('open');
    menuBtn.querySelector('i').className = 'fa-solid fa-bars';
});

// 3. Theme Toggle (Stored)
const themeBtn = document.getElementById('theme-btn');
const root = document.documentElement;
const storedTheme = localStorage.getItem('heng_theme') || 'dark';
root.setAttribute('data-theme', storedTheme);
syncThemeIcon(storedTheme);

themeBtn.onclick = () => {
    const current = root.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    localStorage.setItem('heng_theme', next);
    syncThemeIcon(next);
};

function syncThemeIcon(t) {
    themeBtn.innerHTML = t === 'dark' ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
}

// 4. Dynamic Typewriter
const roles = [
    'Cyber Security Specialist',
    'SOC Analyst & Threat Hunter',
    'Network Security & Firewall Admin',
    'Vulnerability Assessment Pro',
    'Incident Response & Blue Team'
];
let rIdx = 0, cIdx = 0, deleting = false;
const roleEl = document.getElementById('type-role');

function typeLoop() {
    const current = roles[rIdx];
    cIdx += deleting ? -1 : 1;
    roleEl.textContent = current.substring(0, cIdx);

    let speed = deleting ? 30 : 65;
    if (!deleting && cIdx === current.length) {
        speed = 1800;
        deleting = true;
    } else if (deleting && cIdx === 0) {
        deleting = false;
        rIdx = (rIdx + 1) % roles.length;
        speed = 350;
    }
    setTimeout(typeLoop, speed);
}
typeLoop();

// 5. Interactive Console Simulation
const termIn = document.getElementById('term-in');
const termOut = document.getElementById('term-out');

termIn.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        const cmd = termIn.value.trim().toLowerCase();
        execCmd(cmd);
        termIn.value = '';
    }
});

function execCmd(cmd) {
    if (!cmd) return;
    const row = document.createElement('div');
    const prompt = document.createElement('span');
    prompt.style.color = 'var(--sec-cyan)';
    prompt.textContent = 'heng@soc:~$';
    row.appendChild(prompt);
    row.appendChild(document.createTextNode(' ' + cmd));
    termOut.appendChild(row);

    const resp = document.createElement('div');
    if (cmd === 'help') {
        resp.innerHTML = `<div style="color:var(--text-muted);">&bull; skills - View core technical security stack<br>&bull; projects - List defensive infrastructure projects<br>&bull; about - Overview of San Heng<br>&bull; contact - Direct channels<br>&bull; clear - Clear screen</div>`;
    } else if (cmd === 'skills') {
        resp.innerHTML = `<div style="color:var(--sec-emerald);">&bull; Firewalls: pfSense, Fortinet, Mikrotik<br>&bull; SIEM: Wazuh, Splunk, Elastic<br>&bull; Tools: Wireshark, Nmap, Nessus, Suricata<br>&bull; OS: Kali Linux, Ubuntu Server, Active Directory</div>`;
    } else if (cmd === 'projects') {
        resp.innerHTML = `<div style="color:var(--sec-cyan);">&bull; pfSense Firewall &amp; Suricata IDS/IPS<br>&bull; Wazuh SIEM Threat Monitoring<br>&bull; Active Directory CIS Hardening Audit</div>`;
    } else if (cmd === 'about') {
        resp.innerHTML = `<div>San Heng - IT Graduate from Build Bright University specializing in Cyber Security &amp; SOC Operations.</div>`;
    } else if (cmd === 'contact') {
        resp.innerHTML = `<div style="color:var(--sec-cyan);">Telegram: @mason3563 | Phone: 0885407297 | Email: sanheng@gmail.com</div>`;
    } else if (cmd === 'clear') {
        termOut.innerHTML = `<div><span style="color:var(--sec-emerald);">[SYSTEM]</span> Console cleared.</div>`;
        return;
    } else {
        const err = document.createElement('span');
        err.style.color = 'var(--sec-red)';
        err.textContent = `command not found: ${cmd}. Type 'help' for options.`;
        resp.appendChild(err);
    }

    termOut.appendChild(resp);
    termOut.scrollTop = termOut.scrollHeight;
}

// 6. Copy Text Helper with Toast
function copyValue(val, label) {
    navigator.clipboard.writeText(val).then(() => {
        showToast(`Copied ${label}: ${val}`);
    }).catch(() => {
        showToast(`Copied: ${val}`);
    });
}

function showToast(msg) {
    const toast = document.getElementById('toast');
    document.getElementById('toast-text').textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

// 7. Form Submission
function submitMessage(e) {
    e.preventDefault();
    const name = document.getElementById('f-name').value.trim();
    const contact = document.getElementById('f-contact').value.trim();
    const subject = document.getElementById('f-subject').value.trim() || 'Inquiry from portfolio';
    const msg = document.getElementById('f-msg').value.trim();

    // Static GitHub Pages site has no backend, so open the visitor's mail app.
    const body = `${msg}\n\n— ${name}\nContact: ${contact}`;
    window.location.href = `mailto:sanheng@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

    showToast(`Thank you ${name}! Your email app is opening.`);
    document.getElementById('contact-form').reset();
}
